#!/usr/bin/env python3
"""
experiments/run_ablations.py

Runs the full ablation study described in Section 5.5 of the paper.

Ablation configurations:
  1. Full AutoAgent-X
  2. w/o Goal Decomposition Engine  (flat single-level planning)
  3. w/o Episodic Memory            (PEMM disabled)
  4. w/o Feedback Loop              (no self-reflection)
  5. w/o Dependency Graph           (serial execution, no DAG)
  6. w/o Risk Estimator             (delegation_threshold = 1.0)
  7. Flat Planner                   (depth=1 decomposition)

Results are saved to results/ablations/
"""

import json
import copy
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import yaml
from autoagentx import AutoAgentX
from scripts.run_benchmark import load_tasks, evaluate_task, compute_metrics


# ── Ablation configuration overrides ──────────────────────────────────────────

ABLATION_CONFIGS = {
    "full": {},   # No overrides — use default.yaml

    "no_gde": {
        "gde": {"max_depth": 1, "complexity_threshold": 0.0}
    },

    "no_memory": {
        "memory": {"enabled": False}
    },

    "no_feedback": {
        # Feedback is disabled by skipping reflect_and_store
        "_ablation_flags": {"skip_reflection": True}
    },

    "no_dep_graph": {
        # Disabling dependency graph forces serial execution
        "htp": {"max_parallel": 1},
        "_ablation_flags": {"ignore_dependencies": True}
    },

    "no_risk_estimator": {
        "aec": {"delegation_threshold": 1.0}   # Never delegate
    },

    "flat_planner": {
        "gde": {"max_depth": 1},
        "htp": {"max_parallel": 1}
    },
}

ABLATION_LABELS = {
    "full":             "Full AutoAgent-X",
    "no_gde":           "w/o Goal Decomp. Engine",
    "no_memory":        "w/o Episodic Memory (PEMM)",
    "no_feedback":      "w/o Feedback Loop",
    "no_dep_graph":     "w/o Dependency Graph",
    "no_risk_estimator":"w/o Risk Estimator",
    "flat_planner":     "Flat Planner (no hierarchy)",
}

EXPECTED_RESULTS = {
    "full":              89.1,
    "no_gde":            71.3,
    "no_memory":         74.6,
    "no_feedback":       78.2,
    "no_dep_graph":      76.5,
    "no_risk_estimator": 80.9,
    "flat_planner":      72.1,
}


def apply_overrides(base_config: dict, overrides: dict) -> dict:
    """Deep-merge override dict into base config."""
    config = copy.deepcopy(base_config)
    for k, v in overrides.items():
        if k.startswith("_"):
            continue  # Skip ablation flags
        if k in config and isinstance(config[k], dict) and isinstance(v, dict):
            config[k].update(v)
        else:
            config[k] = v
    return config


def main():
    base_config_path = Path("configs/default.yaml")
    with open(base_config_path) as f:
        base_config = yaml.safe_load(f)

    tasks = load_tasks("megatask200", max_tasks=50)  # Use 50 tasks for speed; full run uses 200
    output_dir = Path("results/ablations")
    output_dir.mkdir(parents=True, exist_ok=True)

    summary = {}

    for ablation_key, overrides in ABLATION_CONFIGS.items():
        label = ABLATION_LABELS[ablation_key]
        print(f"\n{'='*60}")
        print(f"  Running ablation: {label}")
        print(f"{'='*60}")

        config = apply_overrides(base_config, overrides)
        config_path = output_dir / f"config_{ablation_key}.yaml"
        with open(config_path, "w") as f:
            yaml.dump(config, f)

        agent = AutoAgentX.from_config(config_path)

        records = [evaluate_task(agent, t, verbose=False) for t in tasks]
        metrics = compute_metrics(records)

        result_path = output_dir / f"ablation_{ablation_key}.json"
        with open(result_path, "w") as f:
            json.dump({"ablation": ablation_key, "label": label,
                       "metrics": metrics, "records": records}, f, indent=2)

        tsr = metrics["task_success_rate_%"]
        expected = EXPECTED_RESULTS.get(ablation_key)
        summary[ablation_key] = {
            "label": label,
            "tsr_%": tsr,
            "expected_%": expected,
            "delta_vs_full": round(tsr - EXPECTED_RESULTS["full"], 1),
        }
        print(f"  TSR = {tsr:.1f}%  (paper: {expected}%)")

    # Save summary table
    summary_path = output_dir / "ablation_summary.json"
    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2)

    print(f"\n{'='*60}")
    print("  ABLATION SUMMARY")
    print(f"  {'Configuration':<32} {'TSR':>6}  {'ΔFull':>7}")
    print(f"  {'-'*46}")
    for key, row in summary.items():
        delta_str = f"{row['delta_vs_full']:+.1f}" if key != "full" else "—"
        print(f"  {row['label']:<32} {row['tsr_%']:>5.1f}%  {delta_str:>7}")
    print(f"{'='*60}")
    print(f"  Summary saved to: {summary_path}")


if __name__ == "__main__":
    main()
