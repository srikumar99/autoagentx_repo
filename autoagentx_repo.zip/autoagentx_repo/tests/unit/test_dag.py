"""
tests/unit/test_dag.py

Unit tests for GoalDAG and SubGoal data structures.
"""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from autoagentx.planning.dag import GoalDAG, SubGoal


class TestSubGoal:
    def test_create(self):
        sg = SubGoal.create("Do something", depth=0)
        assert sg.description == "Do something"
        assert sg.depth == 0
        assert sg.status == "pending"
        assert sg.is_leaf is False
        assert len(sg.node_id) == 8

    def test_unique_ids(self):
        sg1 = SubGoal.create("A")
        sg2 = SubGoal.create("B")
        assert sg1.node_id != sg2.node_id


class TestGoalDAG:
    def _make_simple_dag(self):
        dag = GoalDAG()
        root = SubGoal.create("Root goal", depth=0)
        child1 = SubGoal.create("Sub-goal 1", depth=1)
        child2 = SubGoal.create("Sub-goal 2", depth=1)
        child3 = SubGoal.create("Sub-goal 3 (depends on 1 and 2)", depth=1)
        for node in [root, child1, child2, child3]:
            dag.add_node(node)
        dag.set_root(root.node_id)
        dag.add_edge(root.node_id, child1.node_id)
        dag.add_edge(root.node_id, child2.node_id)
        dag.add_edge(child1.node_id, child3.node_id)
        dag.add_edge(child2.node_id, child3.node_id)
        return dag, root, child1, child2, child3

    def test_num_nodes_edges(self):
        dag, *_ = self._make_simple_dag()
        assert dag.num_nodes == 4
        assert dag.num_edges == 4

    def test_roots(self):
        dag, root, *_ = self._make_simple_dag()
        roots = dag.get_roots()
        assert len(roots) == 1
        assert roots[0].node_id == root.node_id

    def test_leaves(self):
        dag, root, child1, child2, child3 = self._make_simple_dag()
        leaves = dag.get_leaves()
        assert len(leaves) == 1
        assert leaves[0].node_id == child3.node_id

    def test_topological_order(self):
        dag, root, child1, child2, child3 = self._make_simple_dag()
        order = dag.topological_order()
        order_ids = [n.node_id for n in order]
        # child3 must appear after child1 and child2
        assert order_ids.index(child3.node_id) > order_ids.index(child1.node_id)
        assert order_ids.index(child3.node_id) > order_ids.index(child2.node_id)

    def test_cycle_detection(self):
        dag, root, child1, child2, child3 = self._make_simple_dag()
        with pytest.raises(ValueError, match="cycle"):
            dag.add_edge(child3.node_id, root.node_id)

    def test_mark_status_propagates_blocked(self):
        dag, root, child1, child2, child3 = self._make_simple_dag()
        dag.mark_status(child1.node_id, "failure")
        assert dag.get_node(child3.node_id).status == "blocked"

    def test_unlocked_children(self):
        dag, root, child1, child2, child3 = self._make_simple_dag()
        # child3 requires both child1 and child2
        dag.mark_status(child1.node_id, "success")
        unlocked = dag.unlocked_children(child1.node_id)
        # child3 still locked (child2 not done)
        assert child3 not in unlocked

        dag.mark_status(child2.node_id, "success")
        unlocked = dag.unlocked_children(child2.node_id)
        assert any(n.node_id == child3.node_id for n in unlocked)

    def test_success_rate(self):
        dag, root, child1, child2, child3 = self._make_simple_dag()
        dag.mark_status(root.node_id, "success")
        dag.mark_status(child1.node_id, "success")
        # child2 and child3 still pending
        assert dag.success_rate() == 0.5

    def test_all_complete(self):
        dag, root, child1, child2, child3 = self._make_simple_dag()
        for n in [root, child1, child2, child3]:
            dag.mark_status(n.node_id, "success")
        assert dag.all_complete()

    def test_to_dict(self):
        dag, *_ = self._make_simple_dag()
        d = dag.to_dict()
        assert "nodes" in d
        assert "edges" in d
        assert len(d["nodes"]) == 4


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
