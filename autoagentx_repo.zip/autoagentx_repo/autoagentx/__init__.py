"""autoagentx – Hierarchical Goal-Decomposition for Autonomous Multi-Step Task Execution."""

from autoagentx.core.agent import AutoAgentX
from autoagentx.core.config import AutoAgentXConfig
from autoagentx.core.result import AgentResult, TaskStatus

__version__ = "1.0.0"
__all__ = ["AutoAgentX", "AutoAgentXConfig", "AgentResult", "TaskStatus"]
