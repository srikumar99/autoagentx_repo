"""
autoagentx/utils/llm.py

Unified LLM backend abstraction supporting OpenAI, Anthropic, and local models.
Handles retries, token counting, and provider-specific API differences.
"""

from __future__ import annotations

import os
import time
import logging
from typing import Optional

from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

from autoagentx.core.config import LLMConfig
from autoagentx.utils.logging import get_logger

logger = get_logger(__name__)


class LLMBackend:
    """
    Provider-agnostic LLM completion interface.

    Supported providers:
      - openai   : GPT-3.5, GPT-4, GPT-4o (via openai>=1.0)
      - anthropic: Claude-3 family (via anthropic>=0.18)
      - local    : Any OpenAI-compatible server (e.g., LM Studio, Ollama)
    """

    def __init__(self, config: LLMConfig):
        self.config = config
        self._client = self._init_client(config)
        self.total_tokens_used: int = 0

    # ── Public API ─────────────────────────────────────────────────────────────

    def complete(
        self,
        prompt: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        system: Optional[str] = None,
    ) -> str:
        """
        Send a prompt and return the completion text.

        Parameters
        ----------
        prompt       : User-turn content
        temperature  : Override config temperature if provided
        max_tokens   : Override config max_tokens if provided
        system       : Optional system prompt

        Returns
        -------
        str : Completion text
        """
        temp = temperature if temperature is not None else self.config.temperature_plan
        max_tok = max_tokens if max_tokens is not None else self.config.max_tokens

        if self.config.provider == "openai":
            return self._openai_complete(prompt, temp, max_tok, system)
        elif self.config.provider == "anthropic":
            return self._anthropic_complete(prompt, temp, max_tok, system)
        elif self.config.provider == "local":
            return self._local_complete(prompt, temp, max_tok, system)
        else:
            raise ValueError(f"Unknown LLM provider: {self.config.provider!r}")

    # ── OpenAI ─────────────────────────────────────────────────────────────────

    @retry(
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type(Exception),
        reraise=True,
    )
    def _openai_complete(self, prompt: str, temperature: float, max_tokens: int, system: Optional[str]) -> str:
        import openai
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        response = openai.chat.completions.create(
            model=self.config.model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            timeout=self.config.request_timeout,
        )
        usage = response.usage
        if usage:
            self.total_tokens_used += usage.total_tokens
        return response.choices[0].message.content or ""

    # ── Anthropic ──────────────────────────────────────────────────────────────

    @retry(
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        reraise=True,
    )
    def _anthropic_complete(self, prompt: str, temperature: float, max_tokens: int, system: Optional[str]) -> str:
        import anthropic
        client = self._client
        kwargs = dict(
            model=self.config.model,
            max_tokens=max_tokens,
            temperature=temperature,
            messages=[{"role": "user", "content": prompt}],
        )
        if system:
            kwargs["system"] = system
        response = client.messages.create(**kwargs)
        tok = response.usage.input_tokens + response.usage.output_tokens
        self.total_tokens_used += tok
        return response.content[0].text

    # ── Local / OpenAI-compatible ──────────────────────────────────────────────

    def _local_complete(self, prompt: str, temperature: float, max_tokens: int, system: Optional[str]) -> str:
        import openai
        base_url = os.getenv("LOCAL_LLM_URL", "http://localhost:1234/v1")
        client = openai.OpenAI(api_key="local", base_url=base_url)
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        response = client.chat.completions.create(
            model=self.config.model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content or ""

    # ── Client init ────────────────────────────────────────────────────────────

    @staticmethod
    def _init_client(config: LLMConfig):
        if config.provider == "anthropic":
            try:
                import anthropic
                return anthropic.Anthropic(
                    api_key=os.getenv("ANTHROPIC_API_KEY"),
                    timeout=config.request_timeout,
                )
            except ImportError:
                logger.warning("anthropic package not installed; pip install anthropic")
        return None
