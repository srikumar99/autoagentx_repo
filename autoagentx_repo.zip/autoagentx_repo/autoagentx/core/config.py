"""
autoagentx/core/config.py

Pydantic-based configuration dataclasses for AutoAgent-X.
All fields map directly to YAML keys in configs/*.yaml.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class LLMConfig:
    provider: str = "openai"               # openai | anthropic | local
    model: str = "gpt-4-0125-preview"
    temperature_plan: float = 0.0
    temperature_execute: float = 0.2
    max_tokens: int = 4096
    request_timeout: int = 60
    max_retries: int = 5

    @classmethod
    def from_dict(cls, d: dict) -> "LLMConfig":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


@dataclass
class GDEConfig:
    max_depth: int = 8
    complexity_threshold: float = 0.15
    validation: bool = True
    complexity_model_path: str = "weights/complexity_classifier_v1"
    cycle_breaking: str = "min_execution_time"  # min_execution_time | priority

    @classmethod
    def from_dict(cls, d: dict) -> "GDEConfig":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


@dataclass
class HTPConfig:
    max_parallel: int = 4
    token_budget_total: int = 32768
    token_budget_min_per_node: int = 512
    token_budget_max_per_node: int = 8192
    action_selector_model_path: str = "weights/action_selector_v1"

    @classmethod
    def from_dict(cls, d: dict) -> "HTPConfig":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


@dataclass
class AECConfig:
    max_repair_attempts: int = 3
    delegation_threshold: float = 0.65
    repair_strategies: list = field(default_factory=lambda: [
        "rewrite_prompt",
        "substitute_tool",
        "re_decompose",
    ])

    @classmethod
    def from_dict(cls, d: dict) -> "AECConfig":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


@dataclass
class MemoryConfig:
    enabled: bool = True
    top_k_retrieval: int = 5
    embedding_model: str = "text-embedding-ada-002"
    index_path: str = ".autoagentx_memory/faiss.index"
    semantic_cache_path: str = ".autoagentx_memory/semantic_cache.json"

    @classmethod
    def from_dict(cls, d: dict) -> "MemoryConfig":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


@dataclass
class AutoAgentXConfig:
    llm: LLMConfig = field(default_factory=LLMConfig)
    gde: GDEConfig = field(default_factory=GDEConfig)
    htp: HTPConfig = field(default_factory=HTPConfig)
    aec: AECConfig = field(default_factory=AECConfig)
    memory: MemoryConfig = field(default_factory=MemoryConfig)

    @classmethod
    def from_dict(cls, d: dict) -> "AutoAgentXConfig":
        return cls(
            llm=LLMConfig.from_dict(d.get("llm", {})),
            gde=GDEConfig.from_dict(d.get("gde", {})),
            htp=HTPConfig.from_dict(d.get("htp", {})),
            aec=AECConfig.from_dict(d.get("aec", {})),
            memory=MemoryConfig.from_dict(d.get("memory", {})),
        )
