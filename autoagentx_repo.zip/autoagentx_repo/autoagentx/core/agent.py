"""
autoagentx/core/agent.py

Main AutoAgentX agent class — the top-level entry point that wires together
the four architectural layers: GDE → HTP → AEC → PEMM.
"""

from __future__ import annotations

import time
import logging
from pathlib import Path
from typing import Optional

import yaml

from autoagentx.core.config import AutoAgentXConfig
from autoagentx.core.result import AgentResult, TaskStatus
from autoagentx.planning.gde import GoalDecompositionEngine
from autoagentx.planning.htp import HierarchicalTaskPlanner
from autoagentx.execution.aec import AdaptiveExecutionController
from autoagentx.memory.pemm import PersistentEpisodicMemoryModule
from autoagentx.utils.llm import LLMBackend
from autoagentx.utils.logging import get_logger

logger = get_logger(__name__)


class AutoAgentX:
    """
    Hierarchical Goal-Decomposition Model for Autonomous Multi-Step Task Execution.

    Usage::

        agent = AutoAgentX.from_config("configs/default.yaml")
        result = agent.run("Download the latest GDP data for G7 countries and plot a bar chart.")
        print(result.success, result.output)
    """

    def __init__(self, config: AutoAgentXConfig):
        self.config = config

        # Initialise LLM backend (OpenAI / Anthropic / local)
        self.llm = LLMBackend(config.llm)

        # Layer 1 – Goal Decomposition Engine
        self.gde = GoalDecompositionEngine(config.gde, self.llm)

        # Layer 2 – Hierarchical Task Planner
        self.htp = HierarchicalTaskPlanner(config.htp, self.llm)

        # Layer 4 – Persistent Episodic Memory (initialised before AEC so AEC can read it)
        self.memory = PersistentEpisodicMemoryModule(config.memory)

        # Layer 3 – Adaptive Execution Controller
        self.aec = AdaptiveExecutionController(config.aec, self.llm, self.memory)

        logger.info("AutoAgentX initialised with config: %s", config)

    # ------------------------------------------------------------------
    # Factory helpers
    # ------------------------------------------------------------------

    @classmethod
    def from_config(cls, config_path: str | Path) -> "AutoAgentX":
        """Load an agent from a YAML config file."""
        with open(config_path) as f:
            raw = yaml.safe_load(f)
        config = AutoAgentXConfig.from_dict(raw)
        return cls(config)

    @classmethod
    def default(cls) -> "AutoAgentX":
        """Instantiate with sensible defaults (requires OPENAI_API_KEY env var)."""
        return cls.from_config(Path(__file__).parent.parent.parent / "configs" / "default.yaml")

    # ------------------------------------------------------------------
    # Main execution entry point
    # ------------------------------------------------------------------

    def run(
        self,
        task: str,
        context: Optional[dict] = None,
        max_steps: int = 50,
        verbose: bool = True,
    ) -> AgentResult:
        """
        Execute a natural-language task end-to-end.

        Parameters
        ----------
        task:
            Natural-language task description.
        context:
            Optional key/value context injected into the initial world state
            (e.g., {"user_email": "alice@example.com"}).
        max_steps:
            Hard cap on total tool invocations (safety limit).
        verbose:
            If True, log step-by-step progress to stdout.

        Returns
        -------
        AgentResult with fields: success, output, steps, tokens_used, duration_s,
        trajectory, goal_dag, reflections.
        """
        start_time = time.perf_counter()
        logger.info("=== AutoAgentX.run() | task=%r ===", task[:80])

        # ── Step 0: Retrieve relevant episodic memories ──────────────────
        prior_episodes = self.memory.retrieve(task, top_k=self.config.memory.top_k_retrieval)
        if prior_episodes:
            logger.info("Retrieved %d prior episodes from memory.", len(prior_episodes))

        # ── Layer 1: Goal Decomposition ───────────────────────────────────
        logger.info("[Layer 1] Running Goal Decomposition Engine …")
        goal_dag = self.gde.decompose(
            task=task,
            context=context or {},
            prior_episodes=prior_episodes,
        )
        logger.info("[Layer 1] DAG built: %d nodes, %d edges",
                    goal_dag.num_nodes, goal_dag.num_edges)

        # ── Layer 2: Hierarchical Task Planning ───────────────────────────
        logger.info("[Layer 2] Running Hierarchical Task Planner …")
        plan = self.htp.plan(goal_dag, context=context or {})
        logger.info("[Layer 2] Plan ready: %d scheduled nodes", len(plan.nodes))

        # ── Layer 3: Adaptive Execution ───────────────────────────────────
        logger.info("[Layer 3] Running Adaptive Execution Controller …")
        exec_result = self.aec.execute(
            plan=plan,
            dag=goal_dag,
            max_steps=max_steps,
            verbose=verbose,
        )

        # ── Layer 4: Self-reflection & memory update ──────────────────────
        logger.info("[Layer 4] Generating self-reflection and updating memory …")
        reflection = self.memory.reflect_and_store(
            task=task,
            dag=goal_dag,
            trajectory=exec_result.trajectory,
            outcome=exec_result.status,
        )

        duration = time.perf_counter() - start_time
        result = AgentResult(
            task=task,
            status=exec_result.status,
            success=exec_result.status == TaskStatus.SUCCESS,
            output=exec_result.output,
            steps=exec_result.steps,
            tokens_used=exec_result.tokens_used,
            duration_s=round(duration, 2),
            trajectory=exec_result.trajectory,
            goal_dag=goal_dag,
            reflection=reflection,
        )

        logger.info(
            "=== Done | status=%s | steps=%d | tokens=%d | time=%.1fs ===",
            result.status.value, result.steps, result.tokens_used, result.duration_s,
        )
        return result
