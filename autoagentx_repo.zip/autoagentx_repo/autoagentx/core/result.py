"""
autoagentx/core/result.py

Data types for representing task execution results and trajectories.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class TaskStatus(str, Enum):
    SUCCESS = "success"
    FAILURE = "failure"
    PARTIAL = "partial"
    TIMEOUT = "timeout"


@dataclass
class TrajectoryStep:
    """A single step in the execution trajectory."""
    step_id: int
    node_id: str
    sub_goal: str
    tool_name: str
    tool_input: dict
    tool_output: Any
    status: str          # "success" | "failure" | "skipped"
    tokens_used: int
    duration_ms: float
    repair_attempt: int = 0
    error_message: Optional[str] = None


@dataclass
class AgentResult:
    """Complete result of an AutoAgent-X task execution."""
    task: str
    status: TaskStatus
    success: bool
    output: Any

    steps: int
    tokens_used: int
    duration_s: float

    trajectory: list[TrajectoryStep] = field(default_factory=list)
    goal_dag: Any = None          # GoalDAG instance
    reflection: str = ""

    def to_dict(self) -> dict:
        return {
            "task": self.task,
            "status": self.status.value,
            "success": self.success,
            "output": str(self.output),
            "steps": self.steps,
            "tokens_used": self.tokens_used,
            "duration_s": self.duration_s,
            "trajectory": [
                {
                    "step_id": s.step_id,
                    "sub_goal": s.sub_goal,
                    "tool_name": s.tool_name,
                    "status": s.status,
                    "tokens_used": s.tokens_used,
                    "duration_ms": s.duration_ms,
                }
                for s in self.trajectory
            ],
            "reflection": self.reflection,
        }

    def summary(self) -> str:
        lines = [
            f"Task      : {self.task[:80]}{'…' if len(self.task) > 80 else ''}",
            f"Status    : {self.status.value.upper()}",
            f"Steps     : {self.steps}",
            f"Tokens    : {self.tokens_used:,}",
            f"Duration  : {self.duration_s:.1f}s",
            f"Reflection: {self.reflection[:120]}{'…' if len(self.reflection) > 120 else ''}",
        ]
        return "\n".join(lines)
