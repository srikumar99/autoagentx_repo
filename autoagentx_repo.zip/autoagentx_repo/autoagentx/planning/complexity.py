"""autoagentx/planning/complexity.py — Complexity classifier wrapper."""
class ComplexityClassifier:
    def __init__(self, model, tokenizer):
        self.model = model
        self.tokenizer = tokenizer

    def predict(self, text: str) -> float:
        inputs = self.tokenizer(text, return_tensors="pt", truncation=True, max_length=128)
        import torch
        with torch.no_grad():
            logits = self.model(**inputs).logits
            score = torch.sigmoid(logits[0][0]).item()
        return score

    @classmethod
    def load(cls, path: str) -> "ComplexityClassifier":
        from transformers import AutoModelForSequenceClassification, AutoTokenizer
        model = AutoModelForSequenceClassification.from_pretrained(path)
        tokenizer = AutoTokenizer.from_pretrained(path)
        return cls(model, tokenizer)
