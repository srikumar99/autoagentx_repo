"""
autoagentx/planning/dag.py

Directed Acyclic Graph (DAG) data structure for representing
hierarchical goal decompositions.

Each node is a SubGoal; edges encode execution dependencies:
  (u, v) means sub-goal u must complete before v can begin.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Iterator, Optional

import networkx as nx


@dataclass
class SubGoal:
    """A single node in the goal DAG."""
    node_id: str
    description: str
    depth: int
    is_leaf: bool                       # True → maps directly to a tool call
    complexity_score: float = 0.5
    tool_hint: Optional[str] = None     # Suggested tool for leaf nodes
    status: str = "pending"             # pending | running | success | failure | blocked
    output: Optional[object] = None
    error: Optional[str] = None
    token_budget: int = 1024

    @classmethod
    def create(cls, description: str, depth: int = 0) -> "SubGoal":
        return cls(
            node_id=str(uuid.uuid4())[:8],
            description=description,
            depth=depth,
            is_leaf=False,
        )


class GoalDAG:
    """
    Wrapper around a NetworkX DiGraph providing goal-decomposition-specific helpers.

    Invariants maintained:
    - The graph is always a DAG (no cycles).
    - Exactly one root node (in-degree 0) is the top-level goal.
    - All leaf nodes have is_leaf=True.
    """

    def __init__(self):
        self._g: nx.DiGraph = nx.DiGraph()
        self._root_id: Optional[str] = None

    # ── Construction ───────────────────────────────────────────────────

    def add_node(self, sub_goal: SubGoal) -> None:
        self._g.add_node(sub_goal.node_id, data=sub_goal)

    def add_edge(self, from_id: str, to_id: str) -> None:
        """Add dependency edge: from_id must complete before to_id."""
        self._g.add_edge(from_id, to_id)
        if not nx.is_directed_acyclic_graph(self._g):
            self._g.remove_edge(from_id, to_id)
            raise ValueError(f"Adding edge ({from_id}→{to_id}) would create a cycle.")

    def set_root(self, node_id: str) -> None:
        self._root_id = node_id

    # ── Accessors ──────────────────────────────────────────────────────

    @property
    def root(self) -> SubGoal:
        return self._g.nodes[self._root_id]["data"]

    @property
    def num_nodes(self) -> int:
        return self._g.number_of_nodes()

    @property
    def num_edges(self) -> int:
        return self._g.number_of_edges()

    def get_node(self, node_id: str) -> SubGoal:
        return self._g.nodes[node_id]["data"]

    def get_roots(self) -> list[SubGoal]:
        """Return all nodes with in-degree 0 (execution entry points)."""
        return [self._g.nodes[n]["data"] for n in self._g.nodes if self._g.in_degree(n) == 0]

    def get_leaves(self) -> list[SubGoal]:
        return [self._g.nodes[n]["data"]
                for n in self._g.nodes if self._g.out_degree(n) == 0]

    def get_children(self, node_id: str) -> list[SubGoal]:
        return [self._g.nodes[s]["data"] for s in self._g.successors(node_id)]

    def get_parents(self, node_id: str) -> list[SubGoal]:
        return [self._g.nodes[p]["data"] for p in self._g.predecessors(node_id)]

    def unlocked_children(self, node_id: str) -> list[SubGoal]:
        """Return children whose all dependencies are now satisfied."""
        result = []
        for child_id in self._g.successors(node_id):
            parents = list(self._g.predecessors(child_id))
            if all(self._g.nodes[p]["data"].status == "success" for p in parents):
                result.append(self._g.nodes[child_id]["data"])
        return result

    def topological_order(self) -> list[SubGoal]:
        return [self._g.nodes[n]["data"] for n in nx.topological_sort(self._g)]

    def mark_status(self, node_id: str, status: str, output=None, error=None) -> None:
        node = self._g.nodes[node_id]["data"]
        node.status = status
        if output is not None:
            node.output = output
        if error is not None:
            node.error = error
        # Propagate 'blocked' to descendants on failure
        if status == "failure":
            for desc in nx.descendants(self._g, node_id):
                desc_node = self._g.nodes[desc]["data"]
                if desc_node.status == "pending":
                    desc_node.status = "blocked"

    def all_complete(self) -> bool:
        return all(
            self._g.nodes[n]["data"].status in ("success", "failure", "blocked")
            for n in self._g.nodes
        )

    def success_rate(self) -> float:
        total = self._g.number_of_nodes()
        if total == 0:
            return 0.0
        successes = sum(
            1 for n in self._g.nodes
            if self._g.nodes[n]["data"].status == "success"
        )
        return successes / total

    # ── Serialisation ─────────────────────────────────────────────────

    def to_dict(self) -> dict:
        return {
            "nodes": [
                {
                    "id": n,
                    "description": self._g.nodes[n]["data"].description,
                    "depth": self._g.nodes[n]["data"].depth,
                    "is_leaf": self._g.nodes[n]["data"].is_leaf,
                    "complexity": self._g.nodes[n]["data"].complexity_score,
                    "status": self._g.nodes[n]["data"].status,
                }
                for n in self._g.nodes
            ],
            "edges": list(self._g.edges),
            "root_id": self._root_id,
        }

    def __repr__(self) -> str:
        return f"GoalDAG(nodes={self.num_nodes}, edges={self.num_edges}, root={self._root_id})"
