"""
autoagentx/planning/gde.py

Goal Decomposition Engine (GDE) — Layer 1 of AutoAgent-X.

Responsibilities:
  1. Parse natural-language task → structured intent.
  2. Recursively generate child sub-goals until all leaves are primitive actions.
  3. Build the dependency DAG connecting sub-goals.
  4. Validate the DAG (tool reachability, no vacuous nodes, postconditions ⊨ Φ).
"""

from __future__ import annotations

import json
import logging
from typing import Optional

from autoagentx.core.config import GDEConfig
from autoagentx.planning.dag import GoalDAG, SubGoal
from autoagentx.utils.llm import LLMBackend
from autoagentx.utils.logging import get_logger

logger = get_logger(__name__)

# ── Prompt templates ───────────────────────────────────────────────────────────

INTENT_PARSE_PROMPT = """\
You are a task-analysis assistant. Parse the following task into a structured JSON intent.

Task: {task}

Respond ONLY with a JSON object with keys:
  "verbs"          : list of main action verbs
  "objects"        : list of primary objects/entities
  "constraints"    : list of constraints (format, quantity, timing, etc.)
  "success_criteria": list of conditions that must hold for the task to be complete

Example output:
{{
  "verbs": ["download", "summarise", "email"],
  "objects": ["arXiv papers", "abstracts", "report"],
  "constraints": ["top-10", "PDF format"],
  "success_criteria": ["email delivered", "report non-empty"]
}}
"""

DECOMPOSE_PROMPT = """\
You are an expert autonomous agent planner. Decompose the following goal into
3–6 concrete, non-overlapping sub-goals. Each sub-goal should be independently
verifiable and together they must be sufficient to achieve the parent goal.

Parent goal: {goal}
Context: {context}
Previously seen similar tasks: {prior_context}
Current depth: {depth} (max allowed: {max_depth})

If this goal is already primitive (a single tool call), respond with:
{{"is_primitive": true, "tool": "<tool_name>", "reason": "<why>"}}

Otherwise respond with:
{{
  "is_primitive": false,
  "sub_goals": [
    {{"description": "...", "depends_on": []}},
    {{"description": "...", "depends_on": [0]}},
    ...
  ]
}}

"depends_on" contains 0-indexed positions of sub-goals in this list that must
complete before this one can start. Respond ONLY with valid JSON.
"""

VALIDATE_PROMPT = """\
Review the following goal DAG and check for three properties:
1. All leaf nodes describe a single tool call.
2. No sub-goal is vacuous (has empty precondition AND empty effect).
3. The conjunction of all leaf postconditions implies the root goal.

Root goal: {root_goal}
Leaf nodes: {leaves}

Respond with JSON:
{{"valid": true/false, "issues": ["issue1", ...], "fix_hints": ["hint1", ...]}}
"""


class GoalDecompositionEngine:
    """Layer 1: Parses tasks into hierarchical DAGs of sub-goals."""

    KNOWN_TOOLS = {
        "web_search", "web_fetch", "code_executor", "file_read", "file_write",
        "api_caller", "email_sender", "data_analyser", "image_generator",
        "database_query", "shell_command",
    }

    def __init__(self, config: GDEConfig, llm: LLMBackend):
        self.config = config
        self.llm = llm
        self._complexity_model = self._load_complexity_model(config.complexity_model_path)

    # ── Public API ─────────────────────────────────────────────────────────────

    def decompose(
        self,
        task: str,
        context: dict,
        prior_episodes: list,
    ) -> GoalDAG:
        """
        Full decomposition pipeline: parse → decompose → build DAG → validate.

        Parameters
        ----------
        task : str
            Natural-language task description.
        context : dict
            Runtime context (user info, environment state, etc.).
        prior_episodes : list
            Retrieved episodic memories for few-shot guidance.

        Returns
        -------
        GoalDAG
            Validated, execution-ready dependency graph.
        """
        logger.info("GDE.decompose() starting for task: %r", task[:60])

        # Step 1 – Parse intent
        intent = self._parse_intent(task)
        logger.debug("Parsed intent: %s", intent)

        # Step 2 – Build DAG via recursive decomposition
        dag = GoalDAG()
        root = SubGoal.create(description=task, depth=0)
        dag.add_node(root)
        dag.set_root(root.node_id)

        prior_ctx = self._format_prior_context(prior_episodes)
        self._recursive_decompose(dag, root, context, prior_ctx, depth=0)

        logger.info("DAG built: %d nodes, %d edges", dag.num_nodes, dag.num_edges)

        # Step 3 – Validate (retry once on failure)
        if self.config.validation:
            valid, issues = self._validate(dag, task)
            if not valid:
                logger.warning("DAG validation failed: %s. Attempting targeted repair.", issues)
                dag = self._repair(dag, task, context, prior_ctx, issues)

        return dag

    # ── Internal helpers ───────────────────────────────────────────────────────

    def _parse_intent(self, task: str) -> dict:
        prompt = INTENT_PARSE_PROMPT.format(task=task)
        response = self.llm.complete(prompt, temperature=0.0, max_tokens=512)
        try:
            return json.loads(response)
        except json.JSONDecodeError:
            logger.warning("Intent parse JSON error; returning fallback.")
            return {"verbs": [], "objects": [], "constraints": [], "success_criteria": []}

    def _recursive_decompose(
        self,
        dag: GoalDAG,
        node: SubGoal,
        context: dict,
        prior_ctx: str,
        depth: int,
    ) -> None:
        # Check complexity — if below threshold or at max depth, mark as leaf
        node.complexity_score = self._estimate_complexity(node.description)
        if depth >= self.config.max_depth or node.complexity_score <= self.config.complexity_threshold:
            node.is_leaf = True
            node.tool_hint = self._infer_tool(node.description)
            logger.debug("Leaf node at depth %d: %r", depth, node.description[:50])
            return

        prompt = DECOMPOSE_PROMPT.format(
            goal=node.description,
            context=json.dumps(context),
            prior_context=prior_ctx,
            depth=depth,
            max_depth=self.config.max_depth,
        )
        response = self.llm.complete(prompt, temperature=0.0, max_tokens=1024)

        try:
            parsed = json.loads(response)
        except json.JSONDecodeError:
            logger.warning("Decomposition JSON parse error at depth %d; treating as leaf.", depth)
            node.is_leaf = True
            return

        if parsed.get("is_primitive", False):
            node.is_leaf = True
            node.tool_hint = parsed.get("tool")
            return

        sub_goals_data = parsed.get("sub_goals", [])
        if not sub_goals_data:
            node.is_leaf = True
            return

        # Create child SubGoal nodes
        child_nodes = []
        for sg_data in sub_goals_data:
            child = SubGoal.create(description=sg_data["description"], depth=depth + 1)
            dag.add_node(child)
            child_nodes.append(child)

        # Add edges for dependencies (parent→child represents decomposition)
        dag.add_edge(node.node_id, child_nodes[0].node_id)  # root connects to first child
        for idx, child in enumerate(child_nodes):
            for dep_idx in sub_goals_data[idx].get("depends_on", []):
                if dep_idx < idx:
                    try:
                        dag.add_edge(child_nodes[dep_idx].node_id, child.node_id)
                    except ValueError as e:
                        logger.warning("Skipping cycle-inducing edge: %s", e)

        # Recurse on children
        for child in child_nodes:
            self._recursive_decompose(dag, child, context, prior_ctx, depth + 1)

    def _validate(self, dag: GoalDAG, root_goal: str) -> tuple[bool, list[str]]:
        leaves = [sg.description for sg in dag.get_leaves()]
        prompt = VALIDATE_PROMPT.format(root_goal=root_goal, leaves=json.dumps(leaves))
        response = self.llm.complete(prompt, temperature=0.0, max_tokens=512)
        try:
            result = json.loads(response)
            return result.get("valid", True), result.get("issues", [])
        except json.JSONDecodeError:
            return True, []

    def _repair(self, dag: GoalDAG, task: str, context: dict, prior_ctx: str, issues: list) -> GoalDAG:
        """Re-run decomposition for flagged sub-trees; fall back to full rebuild if needed."""
        logger.info("Attempting DAG repair for issues: %s", issues)
        # Simple strategy: rebuild the entire DAG with issue context appended
        new_dag = GoalDAG()
        root = SubGoal.create(description=task, depth=0)
        new_dag.add_node(root)
        new_dag.set_root(root.node_id)
        amended_ctx = dict(context, repair_issues=issues)
        self._recursive_decompose(new_dag, root, amended_ctx, prior_ctx, depth=0)
        return new_dag

    def _estimate_complexity(self, description: str) -> float:
        """Use the fine-tuned complexity classifier, or heuristic fallback."""
        if self._complexity_model is not None:
            return self._complexity_model.predict(description)
        # Heuristic: count conjunctions and subordinate clauses
        keywords = ["and then", "after that", "once", "following", "using the result"]
        score = sum(k in description.lower() for k in keywords) / max(len(keywords), 1)
        return min(1.0, 0.1 + score * 0.6)

    def _infer_tool(self, description: str) -> str:
        desc_lower = description.lower()
        if any(w in desc_lower for w in ["search", "find", "look up", "google"]):
            return "web_search"
        if any(w in desc_lower for w in ["fetch", "download", "retrieve", "http", "url"]):
            return "web_fetch"
        if any(w in desc_lower for w in ["code", "script", "python", "run", "execute"]):
            return "code_executor"
        if any(w in desc_lower for w in ["email", "send", "mail"]):
            return "email_sender"
        if any(w in desc_lower for w in ["write", "save", "store", "create file"]):
            return "file_write"
        if any(w in desc_lower for w in ["read", "open", "load file"]):
            return "file_read"
        if any(w in desc_lower for w in ["api", "call", "request", "endpoint"]):
            return "api_caller"
        if any(w in desc_lower for w in ["analyse", "analyze", "plot", "chart", "visualise"]):
            return "data_analyser"
        return "api_caller"  # default

    @staticmethod
    def _format_prior_context(episodes: list) -> str:
        if not episodes:
            return "None."
        lines = []
        for ep in episodes[:3]:
            lines.append(f"- Task: {ep.get('task', '')[:80]}")
            lines.append(f"  Outcome: {ep.get('outcome', 'unknown')}")
            lines.append(f"  Reflection: {ep.get('reflection', '')[:120]}")
        return "\n".join(lines)

    @staticmethod
    def _load_complexity_model(path: str):
        """Load fine-tuned complexity classifier if available."""
        try:
            from autoagentx.planning.complexity import ComplexityClassifier
            return ComplexityClassifier.load(path)
        except Exception:
            logger.info("Complexity model not found at %s; using heuristic fallback.", path)
            return None
