"""
autoagentx/planning/htp.py
Hierarchical Task Planner (HTP) — Layer 2 of AutoAgent-X.
Receives a validated GoalDAG and produces a scheduled ExecutionPlan.
"""
from dataclasses import dataclass, field
from autoagentx.core.config import HTPConfig
from autoagentx.planning.dag import GoalDAG, SubGoal
from autoagentx.utils.llm import LLMBackend
from autoagentx.utils.logging import get_logger

logger = get_logger(__name__)

@dataclass
class ExecutionPlan:
    nodes: list
    token_budgets: dict = field(default_factory=dict)

class HierarchicalTaskPlanner:
    def __init__(self, config: HTPConfig, llm: LLMBackend):
        self.config = config
        self.llm = llm
        self._action_selector = self._load_action_selector(config.action_selector_model_path)

    def plan(self, dag: GoalDAG, context: dict) -> ExecutionPlan:
        leaves = dag.get_leaves()
        total_complexity = sum(n.complexity_score for n in leaves) or 1
        budgets = {}
        for node in leaves:
            share = node.complexity_score / total_complexity
            budget = int(share * self.config.token_budget_total)
            budget = max(self.config.token_budget_min_per_node,
                         min(self.config.token_budget_max_per_node, budget))
            node.token_budget = budget
            budgets[node.node_id] = budget
        logger.info("HTP: planned %d leaf nodes with budgets assigned.", len(leaves))
        return ExecutionPlan(nodes=dag.topological_order(), token_budgets=budgets)

    @staticmethod
    def _load_action_selector(path: str):
        try:
            import torch
            from transformers import AutoModelForSequenceClassification, AutoTokenizer
            model = AutoModelForSequenceClassification.from_pretrained(path)
            tokenizer = AutoTokenizer.from_pretrained(path)
            return (model, tokenizer)
        except Exception:
            logger.info("Action selector model not found at %s; using heuristic.", path)
            return None
