"""
autoagentx/memory/pemm.py

Persistent Episodic Memory Module (PEMM) — Layer 4 of AutoAgent-X.

Maintains two complementary stores:
  1. Episodic store  — FAISS vector index of full execution traces
  2. Semantic cache  — key-value mapping of tool signatures → observed I/O patterns

Provides:
  - retrieve(task, top_k)           → list of similar past episodes
  - reflect_and_store(...)          → generate self-reflection, persist episode
  - get_semantic_examples(tool)     → few-shot examples for a tool
"""

from __future__ import annotations

import json
import os
import time
import hashlib
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

from autoagentx.core.config import MemoryConfig
from autoagentx.utils.logging import get_logger

logger = get_logger(__name__)


@dataclass
class EpisodicRecord:
    """One complete task episode stored in memory."""
    episode_id: str
    task: str
    outcome: str                     # success | failure | partial
    steps: int
    tokens_used: int
    duration_s: float
    dag_summary: dict                # simplified DAG dict
    reflection: str
    timestamp: float = field(default_factory=time.time)
    embedding: Optional[list] = None  # stored separately in FAISS


REFLECTION_PROMPT = """\
You are a reflective AI agent reviewing your own performance on a completed task.

Task: {task}
Outcome: {outcome}
Number of steps taken: {steps}
Key trajectory events:
{trajectory_summary}

Write a concise self-reflection (3–5 sentences) covering:
1. Was the initial goal decomposition appropriate?
2. Which tool selections were suboptimal, and why?
3. What strategy should be preferred in similar future tasks?

Be specific and actionable. Avoid generic phrases.
"""


class PersistentEpisodicMemoryModule:
    """
    Provides cross-episode learning through retrieval-augmented context injection
    and structured self-reflection generation.
    """

    def __init__(self, config: MemoryConfig):
        self.config = config
        self._records: dict[str, EpisodicRecord] = {}
        self._index = None           # FAISS index (lazy-loaded)
        self._index_ids: list[str] = []  # Maps FAISS row → episode_id
        self._semantic_cache: dict[str, list] = {}

        if config.enabled:
            self._load_from_disk()

    # ── Public API ─────────────────────────────────────────────────────────────

    def retrieve(self, task: str, top_k: int = 5) -> list[dict]:
        """
        Retrieve the top-k most similar past episodes by cosine similarity.

        Returns a list of dicts with keys: task, outcome, reflection.
        """
        if not self.config.enabled or not self._records:
            return []

        embedding = self._embed(task)

        if self._index is not None:
            try:
                import numpy as np
                distances, indices = self._index.search(
                    np.array([embedding], dtype="float32"), min(top_k, len(self._index_ids))
                )
                results = []
                for idx in indices[0]:
                    if 0 <= idx < len(self._index_ids):
                        ep_id = self._index_ids[idx]
                        rec = self._records.get(ep_id)
                        if rec:
                            results.append({
                                "task": rec.task,
                                "outcome": rec.outcome,
                                "reflection": rec.reflection,
                            })
                return results
            except Exception as e:
                logger.warning("FAISS search failed: %s; falling back to linear scan.", e)

        # Linear fallback (no FAISS)
        return [
            {"task": r.task, "outcome": r.outcome, "reflection": r.reflection}
            for r in list(self._records.values())[-top_k:]
        ]

    def reflect_and_store(
        self,
        task: str,
        dag,
        trajectory: list,
        outcome,
    ) -> str:
        """
        Generate a self-reflection for the completed episode and persist it.

        Parameters
        ----------
        task : str
        dag : GoalDAG
        trajectory : list[TrajectoryStep]
        outcome : TaskStatus

        Returns
        -------
        str : The generated self-reflection text.
        """
        from autoagentx.core.result import TaskStatus

        traj_summary = "\n".join(
            f"  Step {s.step_id}: [{s.status}] {s.sub_goal[:60]} via {s.tool_name}"
            for s in trajectory[:10]
        )
        outcome_str = outcome.value if hasattr(outcome, "value") else str(outcome)

        reflection = self._generate_reflection(task, outcome_str, len(trajectory), traj_summary)

        ep_id = hashlib.md5(f"{task}{time.time()}".encode()).hexdigest()[:12]
        record = EpisodicRecord(
            episode_id=ep_id,
            task=task,
            outcome=outcome_str,
            steps=len(trajectory),
            tokens_used=sum(s.tokens_used for s in trajectory),
            duration_s=sum(s.duration_ms for s in trajectory) / 1000,
            dag_summary=dag.to_dict() if dag else {},
            reflection=reflection,
        )
        self._store(ep_id, record)
        logger.info("Episode %s stored in episodic memory.", ep_id)
        return reflection

    def get_semantic_examples(self, tool_name: str) -> list[dict]:
        """Return observed input/output examples for a given tool."""
        return self._semantic_cache.get(tool_name, [])

    def add_semantic_example(self, tool_name: str, example: dict) -> None:
        if tool_name not in self._semantic_cache:
            self._semantic_cache[tool_name] = []
        self._semantic_cache[tool_name].append(example)
        if len(self._semantic_cache[tool_name]) > 20:
            self._semantic_cache[tool_name] = self._semantic_cache[tool_name][-20:]
        self._save_semantic_cache()

    # ── Internal helpers ───────────────────────────────────────────────────────

    def _generate_reflection(
        self, task: str, outcome: str, steps: int, traj_summary: str
    ) -> str:
        from autoagentx.utils.llm import LLMBackend
        # Attempt to use a shared LLM instance; fall back to template if unavailable
        try:
            llm = LLMBackend.__new__(LLMBackend)
            prompt = REFLECTION_PROMPT.format(
                task=task, outcome=outcome, steps=steps, trajectory_summary=traj_summary
            )
            return llm.complete(prompt, temperature=0.3, max_tokens=256)
        except Exception:
            return (
                f"Task '{task[:60]}' completed with outcome '{outcome}' in {steps} steps. "
                f"Review trajectory for improvement opportunities."
            )

    def _embed(self, text: str) -> list[float]:
        """Embed text using OpenAI or a local model."""
        try:
            import openai
            response = openai.embeddings.create(
                model=self.config.embedding_model,
                input=text[:8000],
            )
            return response.data[0].embedding
        except Exception:
            # Fallback: random unit vector (for testing without API key)
            import random, math
            vec = [random.gauss(0, 1) for _ in range(1536)]
            norm = math.sqrt(sum(x * x for x in vec))
            return [x / norm for x in vec]

    def _store(self, ep_id: str, record: EpisodicRecord) -> None:
        self._records[ep_id] = record
        # Add to FAISS index
        embedding = self._embed(record.task)
        record.embedding = embedding
        self._add_to_index(ep_id, embedding)
        self._save_to_disk(ep_id, record)

    def _add_to_index(self, ep_id: str, embedding: list[float]) -> None:
        try:
            import faiss, numpy as np
            vec = np.array([embedding], dtype="float32")
            if self._index is None:
                self._index = faiss.IndexFlatIP(len(embedding))
            self._index.add(vec)
            self._index_ids.append(ep_id)
        except ImportError:
            pass  # FAISS not installed; use linear fallback

    def _load_from_disk(self) -> None:
        index_dir = Path(self.config.index_path).parent
        records_path = index_dir / "episodes.jsonl"
        if records_path.exists():
            with open(records_path) as f:
                for line in f:
                    try:
                        d = json.loads(line)
                        ep_id = d.pop("episode_id", "")
                        embedding = d.pop("embedding", None)
                        rec = EpisodicRecord(episode_id=ep_id, **{
                            k: v for k, v in d.items()
                            if k in EpisodicRecord.__dataclass_fields__
                        })
                        rec.embedding = embedding
                        self._records[ep_id] = rec
                        if embedding:
                            self._add_to_index(ep_id, embedding)
                    except Exception:
                        pass
        # Load semantic cache
        cache_path = Path(self.config.semantic_cache_path)
        if cache_path.exists():
            with open(cache_path) as f:
                self._semantic_cache = json.load(f)
        logger.info("Memory loaded: %d episodes.", len(self._records))

    def _save_to_disk(self, ep_id: str, record: EpisodicRecord) -> None:
        index_dir = Path(self.config.index_path).parent
        index_dir.mkdir(parents=True, exist_ok=True)
        records_path = index_dir / "episodes.jsonl"
        row = asdict(record)
        row["episode_id"] = ep_id
        with open(records_path, "a") as f:
            f.write(json.dumps(row) + "\n")

    def _save_semantic_cache(self) -> None:
        cache_path = Path(self.config.semantic_cache_path)
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        with open(cache_path, "w") as f:
            json.dump(self._semantic_cache, f, indent=2)
