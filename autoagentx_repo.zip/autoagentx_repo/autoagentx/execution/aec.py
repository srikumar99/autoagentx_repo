"""
autoagentx/execution/aec.py

Adaptive Execution Controller (AEC) — Layer 3 of AutoAgent-X.

Implements Algorithm 1 from the paper:
  - Topological dispatch with parallelism up to P_max
  - Per-node tool execution
  - Local repair on failure (3 strategies: rewrite, substitute, re-decompose)
  - Sub-agent delegation for high-complexity leaf nodes
"""

from __future__ import annotations

import time
import asyncio
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional

from autoagentx.core.config import AECConfig
from autoagentx.core.result import TaskStatus, TrajectoryStep
from autoagentx.planning.dag import GoalDAG, SubGoal
from autoagentx.memory.pemm import PersistentEpisodicMemoryModule
from autoagentx.tools import get_tool
from autoagentx.utils.llm import LLMBackend
from autoagentx.utils.logging import get_logger

logger = get_logger(__name__)


class ExecutionResult:
    """Internal result returned by AEC.execute()."""
    def __init__(self):
        self.status: TaskStatus = TaskStatus.FAILURE
        self.output = None
        self.steps: int = 0
        self.tokens_used: int = 0
        self.trajectory: list[TrajectoryStep] = []


class AdaptiveExecutionController:
    """
    Layer 3: Translates a scheduled plan into actual tool invocations,
    monitors execution state, and recovers from failures.
    """

    def __init__(self, config: AECConfig, llm: LLMBackend, memory: PersistentEpisodicMemoryModule):
        self.config = config
        self.llm = llm
        self.memory = memory
        self._step_counter = 0

    # ── Public API ─────────────────────────────────────────────────────────────

    def execute(
        self,
        plan,
        dag: GoalDAG,
        max_steps: int = 50,
        verbose: bool = True,
    ) -> ExecutionResult:
        """
        Execute the plan following the AEC algorithm (Algorithm 1 in paper).

        Parameters
        ----------
        plan : ExecutionPlan
            Scheduled plan from the HTP.
        dag : GoalDAG
            The goal dependency graph (mutated in place with status updates).
        max_steps : int
            Hard cap on total tool invocations.
        verbose : bool
            Print step-by-step progress.

        Returns
        -------
        ExecutionResult
        """
        result = ExecutionResult()
        self._step_counter = 0

        # Initialise ready queue with root-level nodes (no dependencies)
        ready_queue: list[SubGoal] = dag.get_roots()

        while ready_queue and self._step_counter < max_steps:
            # Dispatch up to P_max nodes in parallel
            batch = ready_queue[:self.config.max_parallel]
            ready_queue = ready_queue[self.config.max_parallel:]

            with ThreadPoolExecutor(max_workers=self.config.max_parallel) as pool:
                futures = {
                    pool.submit(self._execute_node, node, dag, plan): node
                    for node in batch
                }
                for future in as_completed(futures):
                    node = futures[future]
                    try:
                        step = future.result()
                        result.trajectory.append(step)
                        result.tokens_used += step.tokens_used
                        self._step_counter += 1

                        if step.status == "success":
                            dag.mark_status(node.node_id, "success", output=step.tool_output)
                            # Unlock children whose dependencies are now all satisfied
                            unlocked = dag.unlocked_children(node.node_id)
                            ready_queue.extend(unlocked)
                            if verbose:
                                logger.info("  ✓ [%d] %s", self._step_counter, node.description[:60])
                        else:
                            dag.mark_status(node.node_id, "failure", error=step.error_message)
                            if verbose:
                                logger.warning("  ✗ [%d] %s | error: %s",
                                               self._step_counter, node.description[:60],
                                               step.error_message)
                    except Exception as exc:
                        logger.error("Unexpected exception for node %s: %s", node.node_id, exc)
                        dag.mark_status(node.node_id, "failure", error=str(exc))

            if dag.all_complete():
                break

        # Determine overall task status
        result.steps = self._step_counter
        sr = dag.success_rate()
        if sr == 1.0:
            result.status = TaskStatus.SUCCESS
        elif sr >= 0.5:
            result.status = TaskStatus.PARTIAL
        else:
            result.status = TaskStatus.FAILURE

        # Collect final output from root node
        result.output = dag.root.output
        return result

    # ── Node execution ─────────────────────────────────────────────────────────

    def _execute_node(self, node: SubGoal, dag: GoalDAG, plan) -> TrajectoryStep:
        """Execute a single leaf node with local repair on failure."""
        dag.mark_status(node.node_id, "running")
        t_start = time.perf_counter()
        tokens_used = 0
        last_error = None

        for attempt in range(self.config.max_repair_attempts + 1):
            try:
                if attempt == 0:
                    output, tokens = self._invoke_tool(node, dag)
                else:
                    output, tokens = self._repair_and_invoke(node, dag, attempt, last_error)

                tokens_used += tokens
                elapsed_ms = (time.perf_counter() - t_start) * 1000
                return TrajectoryStep(
                    step_id=self._step_counter,
                    node_id=node.node_id,
                    sub_goal=node.description,
                    tool_name=node.tool_hint or "unknown",
                    tool_input={},
                    tool_output=output,
                    status="success",
                    tokens_used=tokens_used,
                    duration_ms=round(elapsed_ms, 1),
                    repair_attempt=attempt,
                )
            except Exception as exc:
                last_error = str(exc)
                logger.debug("Node %s attempt %d failed: %s", node.node_id, attempt, exc)

        # All attempts exhausted
        elapsed_ms = (time.perf_counter() - t_start) * 1000
        return TrajectoryStep(
            step_id=self._step_counter,
            node_id=node.node_id,
            sub_goal=node.description,
            tool_name=node.tool_hint or "unknown",
            tool_input={},
            tool_output=None,
            status="failure",
            tokens_used=tokens_used,
            duration_ms=round(elapsed_ms, 1),
            repair_attempt=self.config.max_repair_attempts,
            error_message=last_error,
        )

    def _invoke_tool(self, node: SubGoal, dag: GoalDAG) -> tuple:
        """Build tool input from context and invoke the tool."""
        # Gather outputs of parent nodes as context
        parent_outputs = {
            p.description[:40]: p.output
            for p in dag.get_parents(node.node_id)
            if p.output is not None
        }

        tool_name = node.tool_hint or self._select_tool(node, parent_outputs)

        # Delegate to sub-agent if complexity exceeds threshold
        if node.complexity_score > self.config.delegation_threshold:
            return self._delegate_to_subagent(node, parent_outputs)

        tool = get_tool(tool_name)
        tool_input = self._build_tool_input(node, tool_name, parent_outputs)
        output = tool.run(tool_input)
        tokens = self._estimate_tokens(tool_input, output)
        return output, tokens

    def _repair_and_invoke(self, node: SubGoal, dag: GoalDAG, attempt: int, error: str) -> tuple:
        """Apply repair strategy based on attempt number."""
        strategy = self.config.repair_strategies[min(attempt - 1, len(self.config.repair_strategies) - 1)]
        logger.info("Repair attempt %d for node %s using strategy '%s'", attempt, node.node_id, strategy)

        if strategy == "rewrite_prompt":
            # Re-write tool input incorporating the error message
            rewrite_prompt = (
                f"The following sub-goal failed with error: {error}\n"
                f"Sub-goal: {node.description}\n"
                f"Rewrite the sub-goal more concisely and correctly, "
                f"then suggest the best tool and parameters. Respond in JSON."
            )
            response = self.llm.complete(rewrite_prompt, temperature=0.0, max_tokens=256)
            node.description = response  # simplified; real impl parses JSON
            return self._invoke_tool(node, dag)

        elif strategy == "substitute_tool":
            # Try an alternative tool
            alternatives = self._get_alternative_tools(node.tool_hint)
            if alternatives:
                node.tool_hint = alternatives[0]
            return self._invoke_tool(node, dag)

        elif strategy == "re_decompose":
            # Break the node into finer sub-goals (inline)
            logger.info("Re-decomposing node %s due to repeated failure.", node.node_id)
            node.complexity_score = 0.8  # Force delegation
            return self._delegate_to_subagent(node, {})

        return self._invoke_tool(node, dag)

    def _delegate_to_subagent(self, node: SubGoal, context: dict) -> tuple:
        """Spawn a lightweight sub-agent for high-complexity nodes."""
        from autoagentx.execution.subagent import SubAgent
        agent = SubAgent(self.llm, self.memory)
        output, tokens = agent.run(node.description, context)
        return output, tokens

    def _select_tool(self, node: SubGoal, context: dict) -> str:
        """Ask the action-selection model for the best tool."""
        # Simplified heuristic; production uses f_theta model
        return node.tool_hint or "web_search"

    def _build_tool_input(self, node: SubGoal, tool_name: str, context: dict) -> dict:
        prompt = (
            f"Build the exact JSON input for tool '{tool_name}' to accomplish:\n"
            f"{node.description}\n"
            f"Available context: {context}\n"
            f"Respond ONLY with a JSON object matching the tool's input schema."
        )
        response = self.llm.complete(prompt, temperature=0.0, max_tokens=512)
        import json
        try:
            return json.loads(response)
        except Exception:
            return {"query": node.description}

    @staticmethod
    def _estimate_tokens(inp: dict, out) -> int:
        import json
        return len(json.dumps(inp)) // 4 + len(str(out)) // 4

    @staticmethod
    def _get_alternative_tools(current_tool: Optional[str]) -> list[str]:
        alternatives = {
            "web_search": ["web_fetch", "api_caller"],
            "web_fetch": ["web_search", "api_caller"],
            "code_executor": ["shell_command"],
            "api_caller": ["web_fetch", "web_search"],
        }
        return alternatives.get(current_tool or "", ["web_search"])
