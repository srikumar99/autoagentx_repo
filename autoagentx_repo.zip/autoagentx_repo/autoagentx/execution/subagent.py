"""
autoagentx/execution/subagent.py
Lightweight sub-agent for high-complexity node delegation.
"""
from autoagentx.utils.llm import LLMBackend
from autoagentx.utils.logging import get_logger
logger = get_logger(__name__)

class SubAgent:
    def __init__(self, llm: LLMBackend, memory):
        self.llm = llm
        self.memory = memory

    def run(self, task: str, context: dict) -> tuple:
        prompt = (
            f"You are a focused sub-agent. Complete this specific task:\n{task}\n"
            f"Context: {context}\n"
            f"Respond with the result only."
        )
        output = self.llm.complete(prompt, temperature=0.2, max_tokens=1024)
        tokens = len(prompt) // 4 + len(output) // 4
        logger.info("SubAgent completed task (%d tokens).", tokens)
        return output, tokens
