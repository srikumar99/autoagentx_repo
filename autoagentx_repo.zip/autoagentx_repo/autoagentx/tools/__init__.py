"""
autoagentx/tools/__init__.py

Tool registry — maps tool names to their implementation classes.
All tools inherit from BaseTool and implement run(input_dict) -> Any.
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any

from autoagentx.utils.logging import get_logger

logger = get_logger(__name__)


class BaseTool(ABC):
    """Abstract base class for all AutoAgent-X tools."""

    name: str = "base_tool"
    description: str = "Base tool."

    @abstractmethod
    def run(self, input_dict: dict) -> Any:
        """Execute the tool with the given input and return the result."""
        ...

    def __repr__(self):
        return f"<Tool:{self.name}>"


# ── Concrete Tool Implementations ──────────────────────────────────────────────

class WebSearchTool(BaseTool):
    """Calls a web search API (defaults to SerpAPI / Tavily / DuckDuckGo)."""
    name = "web_search"
    description = "Search the web for information given a query string."

    def run(self, input_dict: dict) -> Any:
        query = input_dict.get("query", "")
        logger.debug("WebSearchTool.run(query=%r)", query[:60])
        try:
            # Prefer Tavily if available
            from tavily import TavilyClient
            import os
            client = TavilyClient(api_key=os.getenv("TAVILY_API_KEY", ""))
            result = client.search(query=query, max_results=5)
            return result
        except Exception:
            # Fallback: return a placeholder
            return {"results": [], "query": query, "status": "api_key_required"}


class WebFetchTool(BaseTool):
    """Fetches and parses the content of a URL."""
    name = "web_fetch"
    description = "Retrieve the text content of a web page given its URL."

    def run(self, input_dict: dict) -> Any:
        import httpx
        url = input_dict.get("url", "")
        logger.debug("WebFetchTool.run(url=%r)", url[:80])
        try:
            response = httpx.get(url, timeout=15, follow_redirects=True)
            response.raise_for_status()
            # Strip HTML tags for clean text
            try:
                from bs4 import BeautifulSoup
                soup = BeautifulSoup(response.text, "html.parser")
                return soup.get_text(separator="\n", strip=True)[:8000]
            except ImportError:
                return response.text[:8000]
        except Exception as e:
            raise RuntimeError(f"WebFetchTool failed for {url}: {e}") from e


class CodeExecutorTool(BaseTool):
    """Executes Python code in a sandboxed subprocess."""
    name = "code_executor"
    description = "Execute a Python code snippet and return stdout/stderr."

    def run(self, input_dict: dict) -> Any:
        import subprocess, tempfile, os
        code = input_dict.get("code", "")
        timeout = input_dict.get("timeout", 30)
        logger.debug("CodeExecutorTool.run() code snippet (%d chars)", len(code))
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(code)
            tmp_path = f.name
        try:
            result = subprocess.run(
                ["python3", tmp_path],
                capture_output=True, text=True, timeout=timeout
            )
            return {"stdout": result.stdout, "stderr": result.stderr, "returncode": result.returncode}
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"Code execution timed out after {timeout}s")
        finally:
            os.unlink(tmp_path)


class FileWriteTool(BaseTool):
    name = "file_write"
    description = "Write content to a local file."

    def run(self, input_dict: dict) -> Any:
        path = input_dict.get("path", "output.txt")
        content = input_dict.get("content", "")
        from pathlib import Path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(content, encoding="utf-8")
        return {"path": path, "bytes_written": len(content.encode())}


class FileReadTool(BaseTool):
    name = "file_read"
    description = "Read the content of a local file."

    def run(self, input_dict: dict) -> Any:
        from pathlib import Path
        path = input_dict.get("path", "")
        return Path(path).read_text(encoding="utf-8")


class APICallerTool(BaseTool):
    name = "api_caller"
    description = "Make an HTTP API call (GET/POST) with optional headers and body."

    def run(self, input_dict: dict) -> Any:
        import httpx
        method = input_dict.get("method", "GET").upper()
        url = input_dict.get("url", "")
        headers = input_dict.get("headers", {})
        body = input_dict.get("body", None)
        params = input_dict.get("params", {})
        logger.debug("APICallerTool.run(%s %s)", method, url[:60])
        try:
            response = httpx.request(
                method, url, headers=headers, json=body, params=params, timeout=20
            )
            return {"status_code": response.status_code, "body": response.text[:4000]}
        except Exception as e:
            raise RuntimeError(f"APICallerTool failed: {e}") from e


class EmailSenderTool(BaseTool):
    name = "email_sender"
    description = "Send an email with optional attachments via SMTP or SendGrid."

    def run(self, input_dict: dict) -> Any:
        import os
        to = input_dict.get("to", "")
        subject = input_dict.get("subject", "(No subject)")
        body = input_dict.get("body", "")
        attachments = input_dict.get("attachments", [])
        logger.info("EmailSenderTool: would send to=%r subject=%r", to, subject)
        # Real implementation uses SendGrid or smtplib; dry-run here
        return {
            "sent": False,
            "dry_run": True,
            "to": to,
            "subject": subject,
            "note": "Set SENDGRID_API_KEY env var to enable real sending.",
        }


# ── Registry ───────────────────────────────────────────────────────────────────

_TOOL_REGISTRY: dict[str, BaseTool] = {
    "web_search": WebSearchTool(),
    "web_fetch": WebFetchTool(),
    "code_executor": CodeExecutorTool(),
    "file_write": FileWriteTool(),
    "file_read": FileReadTool(),
    "api_caller": APICallerTool(),
    "email_sender": EmailSenderTool(),
}


def get_tool(name: str) -> BaseTool:
    """Retrieve a tool by name, raising KeyError if not registered."""
    if name not in _TOOL_REGISTRY:
        logger.warning("Tool %r not in registry; defaulting to web_search.", name)
        return _TOOL_REGISTRY["web_search"]
    return _TOOL_REGISTRY[name]


def register_tool(tool: BaseTool) -> None:
    """Register a custom tool."""
    _TOOL_REGISTRY[tool.name] = tool
    logger.info("Registered custom tool: %s", tool.name)


def list_tools() -> list[str]:
    return list(_TOOL_REGISTRY.keys())
