#!/usr/bin/env python3
"""
scripts/run_benchmark.py

Run AutoAgent-X against any supported benchmark and save results to JSON.

Usage:
    python scripts/run_benchmark.py \
        --benchmark megatask200 \
        --config configs/default.yaml \
        --output results/run1.json \
        --num_workers 4 \
        --domains web_automation scientific_reasoning \
        --difficulty medium hard

Supported benchmarks:
    megatask200   — Our curated 200-task benchmark (https://github.com/autoagentx/megatask200)
    agentbench    — AgentBench (Liu et al., 2023): https://github.com/THUDM/AgentBench
    webarena      — WebArena  (Zhou et al., 2023): https://github.com/web-arena-x/webarena
"""

import argparse
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from autoagentx import AutoAgentX


BENCHMARK_LOADERS = {
    "megatask200": "autoagentx.benchmarks.megatask200:load_tasks",
    "agentbench":  "autoagentx.benchmarks.agentbench:load_tasks",
    "webarena":    "autoagentx.benchmarks.webarena:load_tasks",
}


def parse_args():
    p = argparse.ArgumentParser(description="Run AutoAgent-X on a benchmark suite.")
    p.add_argument("--benchmark", choices=list(BENCHMARK_LOADERS), default="megatask200")
    p.add_argument("--config", default="configs/default.yaml")
    p.add_argument("--output", default="results/benchmark_results.json")
    p.add_argument("--num_workers", type=int, default=1, help="Parallel task workers")
    p.add_argument("--domains", nargs="*", default=None,
                   help="Filter to specific domains (megatask200 only)")
    p.add_argument("--difficulty", nargs="*", default=None,
                   choices=["easy", "medium", "hard"],
                   help="Filter by difficulty (megatask200 only)")
    p.add_argument("--max_tasks", type=int, default=None, help="Limit number of tasks (for debugging)")
    p.add_argument("--verbose", action="store_true")
    return p.parse_args()


def load_tasks(benchmark: str, domains=None, difficulty=None, max_tasks=None) -> list[dict]:
    """Load tasks from the specified benchmark."""
    module_path, func_name = BENCHMARK_LOADERS[benchmark].split(":")
    try:
        import importlib
        module = importlib.import_module(module_path)
        loader = getattr(module, func_name)
        tasks = loader(domains=domains, difficulty=difficulty)
    except (ImportError, AttributeError):
        # Fallback: try loading from a local JSON file
        fallback_path = Path(f"data/{benchmark}_tasks.json")
        if fallback_path.exists():
            with open(fallback_path) as f:
                tasks = json.load(f)
        else:
            print(f"[WARN] Could not load {benchmark}; using 3 sample tasks.")
            tasks = [
                {
                    "id": "sample_001",
                    "task": "Search for the latest news about large language models and write a 200-word summary.",
                    "domain": "web_automation",
                    "difficulty": "easy",
                    "success_criteria": "summary written to file",
                },
                {
                    "id": "sample_002",
                    "task": "Write a Python function that computes the Fibonacci sequence up to n terms, test it, and save it to fibonacci.py.",
                    "domain": "software_engineering",
                    "difficulty": "easy",
                    "success_criteria": "fibonacci.py exists and tests pass",
                },
                {
                    "id": "sample_003",
                    "task": "Fetch GDP data for France, Germany, and Italy from the World Bank API, compute average growth rates, and save a CSV report.",
                    "domain": "data_analysis",
                    "difficulty": "medium",
                    "success_criteria": "CSV file exists with correct columns",
                },
            ]

    # Apply filters
    if domains:
        tasks = [t for t in tasks if t.get("domain") in domains]
    if difficulty:
        tasks = [t for t in tasks if t.get("difficulty") in difficulty]
    if max_tasks:
        tasks = tasks[:max_tasks]

    print(f"Loaded {len(tasks)} tasks from '{benchmark}'.")
    return tasks


def evaluate_task(agent: AutoAgentX, task_item: dict, verbose: bool) -> dict:
    """Run a single task and return the evaluation record."""
    task_id = task_item.get("id", "unknown")
    task_str = task_item.get("task", "")
    t_start = time.perf_counter()

    try:
        result = agent.run(task=task_str, verbose=verbose)
        duration = time.perf_counter() - t_start
        return {
            "id": task_id,
            "domain": task_item.get("domain", ""),
            "difficulty": task_item.get("difficulty", ""),
            "success": result.success,
            "status": result.status.value,
            "steps": result.steps,
            "tokens_used": result.tokens_used,
            "duration_s": round(duration, 2),
            "reflection": result.reflection[:200],
            "error": None,
        }
    except Exception as exc:
        duration = time.perf_counter() - t_start
        return {
            "id": task_id,
            "domain": task_item.get("domain", ""),
            "difficulty": task_item.get("difficulty", ""),
            "success": False,
            "status": "exception",
            "steps": 0,
            "tokens_used": 0,
            "duration_s": round(duration, 2),
            "reflection": "",
            "error": str(exc),
        }


def compute_metrics(records: list[dict]) -> dict:
    total = len(records)
    if total == 0:
        return {}
    successes = sum(1 for r in records if r["success"])
    tsr = successes / total * 100

    successful = [r for r in records if r["success"]]
    avg_steps = sum(r["steps"] for r in successful) / max(len(successful), 1)
    avg_tokens = sum(r["tokens_used"] for r in records) / total
    avg_duration = sum(r["duration_s"] for r in records) / total

    metrics = {
        "total_tasks": total,
        "successful_tasks": successes,
        "task_success_rate_%": round(tsr, 2),
        "avg_steps_successful": round(avg_steps, 2),
        "avg_tokens_per_task": round(avg_tokens, 0),
        "avg_duration_s": round(avg_duration, 2),
    }

    # Per-domain breakdown
    from collections import defaultdict
    by_domain = defaultdict(list)
    for r in records:
        by_domain[r.get("domain", "unknown")].append(r)
    metrics["by_domain"] = {
        domain: {
            "tsr_%": round(sum(1 for r in recs if r["success"]) / len(recs) * 100, 1),
            "n": len(recs),
        }
        for domain, recs in by_domain.items()
    }

    # Per-difficulty breakdown
    by_diff = defaultdict(list)
    for r in records:
        by_diff[r.get("difficulty", "unknown")].append(r)
    metrics["by_difficulty"] = {
        diff: {
            "tsr_%": round(sum(1 for r in recs if r["success"]) / len(recs) * 100, 1),
            "n": len(recs),
        }
        for diff, recs in by_diff.items()
    }

    return metrics


def main():
    args = parse_args()

    print(f"Loading benchmark: {args.benchmark}")
    tasks = load_tasks(
        args.benchmark,
        domains=args.domains,
        difficulty=args.difficulty,
        max_tasks=args.max_tasks,
    )

    print(f"Loading agent from: {args.config}")
    agent = AutoAgentX.from_config(args.config)

    print(f"Running {len(tasks)} tasks with {args.num_workers} worker(s)...")
    records = []
    start_time = time.perf_counter()

    if args.num_workers == 1:
        for i, task_item in enumerate(tasks, 1):
            print(f"  [{i}/{len(tasks)}] {task_item['id']} ...", end=" ")
            record = evaluate_task(agent, task_item, args.verbose)
            status_icon = "✓" if record["success"] else "✗"
            print(f"{status_icon} ({record['steps']} steps, {record['duration_s']}s)")
            records.append(record)
    else:
        with ThreadPoolExecutor(max_workers=args.num_workers) as pool:
            futures = {
                pool.submit(evaluate_task, agent, t, args.verbose): t
                for t in tasks
            }
            done = 0
            for future in as_completed(futures):
                record = future.result()
                records.append(record)
                done += 1
                status_icon = "✓" if record["success"] else "✗"
                print(f"  [{done}/{len(tasks)}] {record['id']} {status_icon}")

    total_time = time.perf_counter() - start_time
    metrics = compute_metrics(records)
    metrics["total_wall_time_s"] = round(total_time, 1)

    output = {
        "benchmark": args.benchmark,
        "config": args.config,
        "metrics": metrics,
        "records": records,
    }

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, "w") as f:
        json.dump(output, f, indent=2)

    print(f"\n{'='*55}")
    print(f"  Benchmark : {args.benchmark}")
    print(f"  Tasks     : {metrics['total_tasks']}")
    print(f"  TSR       : {metrics['task_success_rate_%']}%")
    print(f"  Avg Steps : {metrics['avg_steps_successful']}")
    print(f"  Avg Tokens: {int(metrics['avg_tokens_per_task']):,}")
    print(f"  Wall Time : {total_time:.1f}s")
    print(f"  Results   → {args.output}")
    print(f"{'='*55}")


if __name__ == "__main__":
    main()
