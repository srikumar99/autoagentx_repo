#!/usr/bin/env python3
"""
scripts/download_weights.py

Download pre-trained AutoAgent-X model weights from HuggingFace Hub.

Models:
  complexity_classifier_v1   T5-large fine-tuned goal complexity scorer
  action_selector_v1         125M-param GPT-2-medium action-selection transformer

Usage:
    python scripts/download_weights.py --all
    python scripts/download_weights.py --model complexity_classifier_v1
    python scripts/download_weights.py --model action_selector_v1
"""

import argparse
import sys
from pathlib import Path


HF_REPO = "autoagentx/autoagentx-weights"

MODELS = {
    "complexity_classifier_v1": {
        "hf_path": "complexity_classifier",
        "local_path": "weights/complexity_classifier_v1",
        "description": "T5-large fine-tuned complexity classifier (~220 MB)",
        "files": ["config.json", "pytorch_model.bin", "tokenizer_config.json", "vocab.json"],
    },
    "action_selector_v1": {
        "hf_path": "action_selector",
        "local_path": "weights/action_selector_v1",
        "description": "125M-param action selection transformer (~490 MB)",
        "files": ["config.json", "pytorch_model.bin", "tokenizer_config.json"],
    },
}


def download_model(model_key: str, force: bool = False) -> None:
    if model_key not in MODELS:
        print(f"[ERROR] Unknown model: {model_key!r}. Choose from {list(MODELS)}")
        sys.exit(1)

    info = MODELS[model_key]
    local_dir = Path(info["local_path"])

    if local_dir.exists() and not force:
        print(f"[SKIP] {model_key} already exists at {local_dir}. Use --force to re-download.")
        return

    print(f"Downloading {info['description']} ...")
    local_dir.mkdir(parents=True, exist_ok=True)

    try:
        from huggingface_hub import snapshot_download
        snapshot_download(
            repo_id=HF_REPO,
            allow_patterns=[f"{info['hf_path']}/*"],
            local_dir=str(local_dir.parent),
            local_dir_use_symlinks=False,
        )
        print(f"  ✓ Downloaded to {local_dir}")
    except ImportError:
        print("[ERROR] huggingface_hub not installed. Run: pip install huggingface_hub")
        sys.exit(1)
    except Exception as e:
        print(f"[ERROR] Download failed: {e}")
        print(f"  You can also download manually from: https://huggingface.co/{HF_REPO}")
        sys.exit(1)


def main():
    p = argparse.ArgumentParser(description="Download AutoAgent-X model weights.")
    p.add_argument("--all", action="store_true", help="Download all models")
    p.add_argument("--model", choices=list(MODELS), help="Download a specific model")
    p.add_argument("--force", action="store_true", help="Re-download even if already present")
    args = p.parse_args()

    if not args.all and not args.model:
        p.print_help()
        sys.exit(1)

    if args.all:
        for key in MODELS:
            download_model(key, force=args.force)
    else:
        download_model(args.model, force=args.force)


if __name__ == "__main__":
    main()
