# Pre-trained Weights

Download using:
```bash
python scripts/download_weights.py --all
```

Or manually from: https://huggingface.co/autoagentx/autoagentx-weights

| Model | Size | Description |
|-------|------|-------------|
| complexity_classifier_v1/ | ~220 MB | T5-large fine-tuned goal complexity scorer |
| action_selector_v1/ | ~490 MB | 125M-param action-selection transformer |
